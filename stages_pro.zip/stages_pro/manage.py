#!/usr/bin/env python
import os
import sys


def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as erreur:
        raise ImportError(
            "Django n'est pas installé. Lancez : pip install -r requirements.txt"
        ) from erreur
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
