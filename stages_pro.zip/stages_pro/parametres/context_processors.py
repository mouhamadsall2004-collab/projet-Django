from .models import ParametresSite


def site(request):
    """Rend les paramètres du site disponibles dans tous les templates : {{ site.nom_site }}."""
    return {"site": ParametresSite.charger()}
