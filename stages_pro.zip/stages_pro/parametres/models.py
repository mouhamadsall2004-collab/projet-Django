from django.db import models


class ParametresSite(models.Model):
    """Réglages modifiables du site. Il n'y a qu'une seule ligne dans la table."""

    nom_site = models.CharField("nom du site", max_length=80, default="Stages et Emplois")
    titre_accueil = models.CharField(
        "titre de la page d'accueil",
        max_length=140,
        default="Trouvez le stage ou l'emploi qui lance votre carrière",
    )
    sous_titre_accueil = models.CharField(
        "texte sous le titre",
        max_length=255,
        default="Les entreprises publient leurs offres, les étudiants postulent et suivent leurs candidatures au même endroit.",
    )
    email_contact = models.EmailField("e-mail de contact", blank=True)
    telephone_contact = models.CharField("téléphone de contact", max_length=30, blank=True)
    adresse = models.CharField("adresse", max_length=160, blank=True)

    class Meta:
        verbose_name = "paramètres du site"
        verbose_name_plural = "paramètres du site"

    @classmethod
    def charger(cls):
        """Renvoie les paramètres, et les crée avec les valeurs par défaut au premier appel."""
        parametres, _ = cls.objects.get_or_create(pk=1)
        return parametres

    def save(self, *args, **kwargs):
        self.pk = 1  # une seule ligne
        super().save(*args, **kwargs)

    def __str__(self):
        return "Paramètres du site"
