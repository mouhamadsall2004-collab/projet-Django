from django import forms
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm, UserCreationForm
from django.db import transaction

from .mixins import StyledFormMixin
from .models import SECTEURS, Entreprise, Etudiant, Utilisateur


class ConnexionForm(StyledFormMixin, AuthenticationForm):
    pass


class MotDePasseForm(StyledFormMixin, PasswordChangeForm):
    pass


class _InscriptionBaseForm(StyledFormMixin, UserCreationForm):
    """Champs communs aux deux inscriptions."""

    role = None  # précisé dans chaque sous-classe

    class Meta(UserCreationForm.Meta):
        model = Utilisateur
        fields = ("username", "first_name", "last_name", "email", "telephone")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["first_name"].required = True
        self.fields["last_name"].required = True
        self.fields["email"].required = True

    def clean_email(self):
        email = self.cleaned_data["email"]
        if Utilisateur.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Cette adresse e-mail est déjà utilisée.")
        return email


class InscriptionEtudiantForm(_InscriptionBaseForm):
    role = Utilisateur.Role.ETUDIANT

    formation = forms.CharField(label="Formation", max_length=150, required=False)
    niveau = forms.ChoiceField(label="Niveau", choices=Etudiant.Niveau.choices, initial="L3")
    competences = forms.CharField(
        label="Compétences",
        required=False,
        help_text="Séparez-les par des virgules, par exemple : Python, Django, SQL.",
    )

    @transaction.atomic
    def save(self, commit=True):
        utilisateur = super().save(commit=False)
        utilisateur.role = self.role
        utilisateur.save()
        Etudiant.objects.create(
            utilisateur=utilisateur,
            formation=self.cleaned_data["formation"],
            niveau=self.cleaned_data["niveau"],
            competences=self.cleaned_data["competences"],
        )
        return utilisateur


class InscriptionEntrepriseForm(_InscriptionBaseForm):
    role = Utilisateur.Role.ENTREPRISE

    nom_entreprise = forms.CharField(label="Nom de l'entreprise", max_length=150)
    secteur = forms.ChoiceField(label="Secteur d'activité", choices=SECTEURS)
    localisation = forms.CharField(label="Ville", max_length=150, required=False)

    @transaction.atomic
    def save(self, commit=True):
        utilisateur = super().save(commit=False)
        utilisateur.role = self.role
        utilisateur.save()
        Entreprise.objects.create(
            utilisateur=utilisateur,
            nom=self.cleaned_data["nom_entreprise"],
            secteur=self.cleaned_data["secteur"],
            localisation=self.cleaned_data["localisation"],
        )
        return utilisateur


# Modification du profil
class UtilisateurForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Utilisateur
        fields = ("first_name", "last_name", "email", "telephone")


class EtudiantForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Etudiant
        fields = ("formation", "niveau", "etablissement", "competences", "presentation", "cv")
        widgets = {"presentation": forms.Textarea(attrs={"rows": 4})}


class EntrepriseForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Entreprise
        fields = ("nom", "secteur", "localisation", "site_web", "description")
        widgets = {"description": forms.Textarea(attrs={"rows": 5})}
