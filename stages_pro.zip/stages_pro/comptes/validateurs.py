from django.core.exceptions import ValidationError

TAILLE_MAX = 5 * 1024 * 1024  # 5 Mo


def valider_taille(fichier):
    """Refuse les fichiers de plus de 5 Mo."""
    if fichier.size > TAILLE_MAX:
        raise ValidationError("Le fichier ne doit pas dépasser 5 Mo.")
