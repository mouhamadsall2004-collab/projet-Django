from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views

app_name = "comptes"

urlpatterns = [
    path("connexion/", views.ConnexionView.as_view(), name="connexion"),
    path("deconnexion/", LogoutView.as_view(), name="deconnexion"),
    path("inscription/", views.ChoixInscriptionView.as_view(), name="inscription"),
    path("inscription/etudiant/", views.InscriptionEtudiantView.as_view(), name="inscription_etudiant"),
    path("inscription/entreprise/", views.InscriptionEntrepriseView.as_view(), name="inscription_entreprise"),
    path("profil/", views.profil, name="profil"),
    path("mot-de-passe/", views.MotDePasseView.as_view(), name="mot_de_passe"),
]
