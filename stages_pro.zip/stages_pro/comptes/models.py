from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator
from django.db import models

from .validateurs import valider_taille

SECTEURS = [
    ("informatique", "Informatique et numérique"),
    ("finance", "Banque et finance"),
    ("sante", "Santé"),
    ("education", "Éducation et formation"),
    ("commerce", "Commerce et marketing"),
    ("industrie", "Industrie et énergie"),
    ("telecom", "Télécommunications"),
    ("agriculture", "Agriculture et agroalimentaire"),
    ("transport", "Transport et logistique"),
    ("autre", "Autre"),
]


class HorodatageModel(models.Model):
    """Classe abstraite : date de création et de dernière modification."""

    date_creation = models.DateTimeField("créé le", auto_now_add=True)
    date_modification = models.DateTimeField("modifié le", auto_now=True)

    class Meta:
        abstract = True


class Utilisateur(AbstractUser):
    """Compte de connexion. Le rôle décide de ce que la personne peut faire."""

    class Role(models.TextChoices):
        ETUDIANT = "etudiant", "Étudiant"
        ENTREPRISE = "entreprise", "Entreprise"
        ADMIN = "admin", "Administrateur"

    role = models.CharField("rôle", max_length=12, choices=Role.choices, default=Role.ETUDIANT)
    telephone = models.CharField("téléphone", max_length=20, blank=True)

    class Meta:
        verbose_name = "utilisateur"
        verbose_name_plural = "utilisateurs"

    def save(self, *args, **kwargs):
        # un compte créé avec createsuperuser est toujours administrateur
        if self.is_superuser:
            self.role = self.Role.ADMIN
        super().save(*args, **kwargs)

    @property
    def est_etudiant(self):
        return self.role == self.Role.ETUDIANT

    @property
    def est_entreprise(self):
        return self.role == self.Role.ENTREPRISE

    @property
    def est_admin(self):
        return self.role == self.Role.ADMIN

    @property
    def nom_complet(self):
        return self.get_full_name() or self.username

    def obtenir_profil(self):
        """Renvoie le profil lié au rôle, et le crée s'il manque."""
        if self.est_etudiant:
            return Etudiant.objects.get_or_create(utilisateur=self)[0]
        if self.est_entreprise:
            return Entreprise.objects.get_or_create(
                utilisateur=self, defaults={"nom": self.username}
            )[0]
        return None

    def __str__(self):
        return f"{self.nom_complet} ({self.get_role_display()})"


class Profil(HorodatageModel):
    """Classe abstraite commune aux profils Etudiant et Entreprise."""

    utilisateur = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="%(class)s",  # donne utilisateur.etudiant et utilisateur.entreprise
    )

    class Meta:
        abstract = True

    def nom_affichage(self):
        return self.utilisateur.nom_complet

    def resume(self):
        return ""


class Etudiant(Profil):
    class Niveau(models.TextChoices):
        L1 = "L1", "Licence 1"
        L2 = "L2", "Licence 2"
        L3 = "L3", "Licence 3"
        M1 = "M1", "Master 1"
        M2 = "M2", "Master 2"
        AUTRE = "AUTRE", "Autre"

    formation = models.CharField("formation", max_length=150, blank=True)
    niveau = models.CharField("niveau", max_length=5, choices=Niveau.choices, default=Niveau.L3)
    etablissement = models.CharField("établissement", max_length=150, blank=True)
    competences = models.TextField(
        "compétences", blank=True, help_text="Séparez les compétences par des virgules."
    )
    presentation = models.TextField("présentation", blank=True)
    cv = models.FileField(
        "CV (PDF)",
        upload_to="cv/",
        blank=True,
        validators=[FileExtensionValidator(["pdf"]), valider_taille],
    )

    class Meta:
        verbose_name = "étudiant"
        verbose_name_plural = "étudiants"

    @property
    def liste_competences(self):
        return [c.strip() for c in self.competences.split(",") if c.strip()]

    def resume(self):
        morceaux = [self.formation, self.get_niveau_display()]
        return " - ".join(m for m in morceaux if m)

    def __str__(self):
        return self.nom_affichage()


class Entreprise(Profil):
    nom = models.CharField("nom de l'entreprise", max_length=150)
    secteur = models.CharField("secteur", max_length=20, choices=SECTEURS, default="autre")
    localisation = models.CharField("localisation", max_length=150, blank=True)
    site_web = models.URLField("site web", blank=True)
    description = models.TextField("présentation", blank=True)

    class Meta:
        verbose_name = "entreprise"
        verbose_name_plural = "entreprises"

    def nom_affichage(self):
        return self.nom

    def resume(self):
        morceaux = [self.get_secteur_display(), self.localisation]
        return " - ".join(m for m in morceaux if m)

    def __str__(self):
        return self.nom
