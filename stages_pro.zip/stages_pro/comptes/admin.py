from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Entreprise, Etudiant, Utilisateur


@admin.register(Utilisateur)
class UtilisateurAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (("Plateforme", {"fields": ("role", "telephone")}),)
    add_fieldsets = UserAdmin.add_fieldsets + (("Plateforme", {"fields": ("role", "telephone")}),)
    list_display = ("username", "email", "role", "is_active", "date_joined")
    list_filter = ("role", "is_active")


@admin.register(Etudiant)
class EtudiantAdmin(admin.ModelAdmin):
    list_display = ("utilisateur", "formation", "niveau", "etablissement")
    search_fields = ("utilisateur__username", "utilisateur__last_name", "formation")


@admin.register(Entreprise)
class EntrepriseAdmin(admin.ModelAdmin):
    list_display = ("nom", "secteur", "localisation", "utilisateur")
    list_filter = ("secteur",)
    search_fields = ("nom", "localisation")
