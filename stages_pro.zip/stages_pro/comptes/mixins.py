from functools import wraps

from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied


class RoleRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Vue classe réservée à certains rôles.

    Visiteur non connecté : redirigé vers la connexion.
    Mauvais rôle : erreur 403.
    """

    roles_autorises = ()

    def test_func(self):
        return self.request.user.role in self.roles_autorises


def role_required(*roles):
    """Même protection pour les vues fonctions."""

    def decorateur(vue):
        @wraps(vue)
        def enveloppe(request, *args, **kwargs):
            if request.user.role not in roles:
                raise PermissionDenied
            return vue(request, *args, **kwargs)

        return login_required(enveloppe)

    return decorateur


class QuerystringMixin:
    """Garde les filtres de recherche dans les liens de pagination."""

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        parametres = self.request.GET.copy()
        parametres.pop("page", None)
        contexte["querystring"] = parametres.urlencode()
        return contexte


class SuppressionMixin:
    """Page de confirmation avant une suppression (à placer avant DeleteView)."""

    template_name = "confirmer_suppression.html"
    message_succes = "L'élément « {objet} » a été supprimé."
    message_avertissement = "Cette action est définitive."
    url_retour = None

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["message_avertissement"] = self.message_avertissement
        contexte["url_retour"] = self.url_retour or self.get_success_url()
        return contexte

    def form_valid(self, form):
        libelle = str(self.object)
        reponse = super().form_valid(form)
        messages.success(self.request, self.message_succes.format(objet=libelle))
        return reponse


class StyledFormMixin:
    """Ajoute les classes CSS du site à tous les champs d'un formulaire."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for champ in self.fields.values():
            widget = champ.widget
            if isinstance(widget, forms.CheckboxInput):
                classe = "case"
            elif isinstance(widget, forms.FileInput):
                classe = "saisie saisie-fichier"
            else:
                classe = "saisie"
            widget.attrs["class"] = f"{widget.attrs.get('class', '')} {classe}".strip()
