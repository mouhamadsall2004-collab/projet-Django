from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, PasswordChangeView
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views.generic import FormView, TemplateView

from .forms import (
    ConnexionForm,
    EntrepriseForm,
    EtudiantForm,
    InscriptionEntrepriseForm,
    InscriptionEtudiantForm,
    MotDePasseForm,
    UtilisateurForm,
)


class ConnexionView(LoginView):
    template_name = "comptes/connexion.html"
    authentication_form = ConnexionForm
    redirect_authenticated_user = True


class ChoixInscriptionView(TemplateView):
    template_name = "comptes/choix_inscription.html"


class _InscriptionView(FormView):
    # crée le compte, connecte la personne, puis l'envoie vers son espace
    template_name = "comptes/inscription.html"
    titre = ""

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("tableau_bord:index")
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["titre"] = self.titre
        return contexte

    def form_valid(self, form):
        utilisateur = form.save()
        login(self.request, utilisateur)
        messages.success(self.request, "Votre compte a été créé. Bienvenue !")
        return redirect("tableau_bord:index")


class InscriptionEtudiantView(_InscriptionView):
    form_class = InscriptionEtudiantForm
    titre = "Inscription étudiant"


class InscriptionEntrepriseView(_InscriptionView):
    form_class = InscriptionEntrepriseForm
    titre = "Inscription entreprise"


@login_required
def profil(request):
    utilisateur = request.user
    profil_utilisateur = utilisateur.obtenir_profil()
    classe_profil = {"etudiant": EtudiantForm, "entreprise": EntrepriseForm}.get(utilisateur.role)

    if request.method == "POST":
        form_compte = UtilisateurForm(request.POST, instance=utilisateur)
        form_profil = None
        if classe_profil:
            form_profil = classe_profil(request.POST, request.FILES, instance=profil_utilisateur)

        if form_compte.is_valid() and (form_profil is None or form_profil.is_valid()):
            form_compte.save()
            if form_profil:
                form_profil.save()
            messages.success(request, "Votre profil a été mis à jour.")
            return redirect("comptes:profil")
    else:
        form_compte = UtilisateurForm(instance=utilisateur)
        form_profil = classe_profil(instance=profil_utilisateur) if classe_profil else None

    return render(
        request,
        "comptes/profil.html",
        {"form_compte": form_compte, "form_profil": form_profil, "profil": profil_utilisateur},
    )


class MotDePasseView(PasswordChangeView):
    template_name = "comptes/mot_de_passe.html"
    form_class = MotDePasseForm
    success_url = reverse_lazy("comptes:profil")

    def form_valid(self, form):
        messages.success(self.request, "Votre mot de passe a été modifié.")
        return super().form_valid(form)
