from django.test import TestCase
from django.urls import reverse

from comptes.models import Entreprise, Etudiant, Utilisateur


class ComptesTests(TestCase):
    def donnees(self, **en_plus):
        base = {
            "username": "nouveau",
            "first_name": "Awa",
            "last_name": "Diop",
            "email": "awa@example.com",
            "password1": "Motdepasse-2025",
            "password2": "Motdepasse-2025",
        }
        base.update(en_plus)
        return base

    def test_inscription_etudiant_cree_le_profil(self):
        self.client.post(reverse("comptes:inscription_etudiant"), self.donnees(niveau="L3"))
        utilisateur = Utilisateur.objects.get(username="nouveau")
        self.assertEqual(utilisateur.role, "etudiant")
        self.assertTrue(Etudiant.objects.filter(utilisateur=utilisateur).exists())

    def test_inscription_entreprise_cree_le_profil(self):
        self.client.post(
            reverse("comptes:inscription_entreprise"),
            self.donnees(nom_entreprise="Ma société", secteur="informatique"),
        )
        self.assertTrue(Entreprise.objects.filter(nom="Ma société").exists())

    def test_un_superutilisateur_est_administrateur(self):
        admin = Utilisateur.objects.create_superuser("chef", "chef@example.com", "Motdepasse123")
        self.assertTrue(admin.est_admin)

    def test_deconnexion_par_post(self):
        Utilisateur.objects.create_user("u1", password="Motdepasse123")
        self.client.login(username="u1", password="Motdepasse123")
        self.client.post(reverse("comptes:deconnexion"))
        self.assertEqual(self.client.get(reverse("tableau_bord:index")).status_code, 302)
