# Plateforme de Gestion des Stages et des Offres d'Emploi

Projet de fin de module POO Python / Django, 2025-2026 (Dr Maty SENE).
Base de données : SQLite. Aucune donnée de démonstration n'est créée : la base démarre vide.

## Installation

```bash
python -m venv venv
source venv/bin/activate        # Windows : venv\Scripts\activate
pip install -r requirements.txt

python manage.py makemigrations comptes offres candidatures parametres tableau_bord
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Ouvrir ensuite http://127.0.0.1:8000/

Le super-utilisateur est automatiquement administrateur de la plateforme.

## Premiers pas

1. Se connecter avec le compte administrateur, puis ouvrir `Administration`.
2. `Paramètres du site` : changer le nom du site, les textes de l'accueil et les coordonnées.
3. Les entreprises et les étudiants créent leurs comptes depuis `Créer un compte`.

## Fonctions principales

- Étudiant : recherche d'offres, candidature avec lettre et CV, suivi des statuts, offres enregistrées.
- Entreprise : publication et clôture d'offres, traitement des candidatures, export CSV.
- Administrateur : comptes, modération, paramètres du site, suppression des données.
- Le site n'utilise aucune image : le design repose uniquement sur le CSS.

## Ce que l'administrateur peut supprimer

- Un compte (page `Comptes`), avec son profil, ses offres et ses candidatures. Son propre compte et les super-utilisateurs sont protégés.
- Une offre (page `Offres`) ou une candidature (page `Candidatures`), après confirmation.
- Page `Base de données` : supprimer toutes les candidatures, toutes les offres ou tous les comptes étudiants/entreprises. Il faut taper `SUPPRIMER` pour confirmer. Les administrateurs sont conservés.
- Base totalement vide : supprimer `db.sqlite3`, puis refaire `migrate` et `createsuperuser`.

## Tests

```bash
python manage.py test
```

## Structure

| Dossier | Rôle |
|---|---|
| `comptes` | utilisateur personnalisé, profils Étudiant et Entreprise, inscription, connexion |
| `offres` | offres de stage et d'emploi, recherche, publication, offres enregistrées |
| `candidatures` | dépôt, suivi et traitement des candidatures |
| `parametres` | paramètres du site (textes de l'accueil, contact) |
| `tableau_bord` | accueil, tableaux de bord par rôle, administration |
