from django import forms

from comptes.mixins import StyledFormMixin

from .models import Candidature


class CandidatureForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Candidature
        fields = ["lettre_motivation", "cv"]
        widgets = {
            "lettre_motivation": forms.Textarea(
                attrs={"rows": 9, "placeholder": "Présentez votre parcours et votre motivation."}
            )
        }

    def clean_lettre_motivation(self):
        lettre = self.cleaned_data["lettre_motivation"].strip()
        if len(lettre) < 30:
            raise forms.ValidationError("La lettre est trop courte (30 caractères minimum).")
        return lettre
