import csv

from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.http import HttpResponse
from django.db import IntegrityError, transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from comptes.mixins import role_required
from comptes.models import Utilisateur
from offres.models import Offre

from .forms import CandidatureForm
from .models import Candidature

ETUDIANT = Utilisateur.Role.ETUDIANT
ENTREPRISE = Utilisateur.Role.ENTREPRISE
ADMIN = Utilisateur.Role.ADMIN


def paginer(request, queryset, par_page=10):
    return Paginator(queryset, par_page).get_page(request.GET.get("page"))


@role_required(ETUDIANT)
def postuler(request, offre_pk):
    offre = get_object_or_404(Offre.objects.ouvertes().select_related("entreprise"), pk=offre_pk)
    etudiant = request.user.obtenir_profil()

    # une seule candidature par offre
    if Candidature.objects.filter(etudiant=etudiant, offre=offre).exists():
        messages.warning(request, "Vous avez déjà postulé à cette offre.")
        return redirect("offres:detail", pk=offre.pk)

    form = CandidatureForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        candidature = form.save(commit=False)
        candidature.etudiant = etudiant
        candidature.offre = offre
        try:
            with transaction.atomic():
                candidature.save()
        except IntegrityError:
            messages.warning(request, "Vous avez déjà postulé à cette offre.")
            return redirect("offres:detail", pk=offre.pk)
        messages.success(request, "Votre candidature a bien été envoyée.")
        return redirect("candidatures:mes_candidatures")

    return render(request, "candidatures/postuler.html", {"form": form, "offre": offre})


@role_required(ETUDIANT)
def mes_candidatures(request):
    candidatures = Candidature.objects.filter(etudiant__utilisateur=request.user).select_related(
        "offre", "offre__entreprise"
    )
    statut = request.GET.get("statut", "")
    if statut in Candidature.Statut.values:
        candidatures = candidatures.filter(statut=statut)

    contexte = {
        "page": paginer(request, candidatures),
        "statuts": Candidature.Statut.choices,
        "statut_actif": statut,
    }
    return render(request, "candidatures/mes_candidatures.html", contexte)


@role_required(ENTREPRISE)
def candidatures_recues(request):
    candidatures = Candidature.objects.filter(offre__entreprise__utilisateur=request.user).select_related(
        "etudiant", "etudiant__utilisateur", "offre"
    )
    offre = None
    offre_id = request.GET.get("offre", "")
    if offre_id.isdigit():
        offre = get_object_or_404(Offre, pk=offre_id, entreprise__utilisateur=request.user)
        candidatures = candidatures.filter(offre=offre)

    statut = request.GET.get("statut", "")
    if statut in Candidature.Statut.values:
        candidatures = candidatures.filter(statut=statut)

    parametres = request.GET.copy()
    parametres.pop("page", None)
    contexte = {
        "page": paginer(request, candidatures),
        "offre": offre,
        "statuts": Candidature.Statut.choices,
        "statut_actif": statut,
        "querystring": parametres.urlencode(),
    }
    return render(request, "candidatures/recues.html", contexte)


@role_required(ETUDIANT, ENTREPRISE, ADMIN)
def candidature_detail(request, pk):
    candidature = get_object_or_404(
        Candidature.objects.select_related(
            "etudiant", "etudiant__utilisateur", "offre", "offre__entreprise", "offre__entreprise__utilisateur"
        ),
        pk=pk,
    )
    utilisateur = request.user
    est_etudiant = candidature.etudiant.utilisateur_id == utilisateur.pk
    est_entreprise = candidature.offre.entreprise.utilisateur_id == utilisateur.pk
    if not (est_etudiant or est_entreprise or utilisateur.est_admin):
        raise PermissionDenied

    contexte = {
        "candidature": candidature,
        "est_etudiant": est_etudiant,
        "est_entreprise": est_entreprise,
        "statuts_attribuables": [(s.value, s.label) for s in Candidature.STATUTS_ATTRIBUABLES],
    }
    return render(request, "candidatures/detail.html", contexte)


@role_required(ENTREPRISE)
@require_POST
def changer_statut(request, pk):
    candidature = get_object_or_404(Candidature, pk=pk, offre__entreprise__utilisateur=request.user)
    try:
        candidature.changer_statut(request.POST.get("statut", ""))
    except ValueError:
        messages.error(request, "Statut invalide.")
    else:
        messages.success(request, f"Candidature passée au statut « {candidature.get_statut_display()} ».")
    return redirect("candidatures:detail", pk=candidature.pk)


@role_required(ETUDIANT)
@require_POST
def retirer(request, pk):
    candidature = get_object_or_404(Candidature, pk=pk, etudiant__utilisateur=request.user)
    if candidature.peut_etre_retiree:
        candidature.delete()
        messages.success(request, "Votre candidature a été retirée.")
    else:
        messages.error(request, "Cette candidature est déjà en cours de traitement.")
    return redirect("candidatures:mes_candidatures")


@role_required(ENTREPRISE)
def exporter_csv(request):
    """Télécharge les candidatures reçues dans un fichier lisible avec Excel."""
    candidatures = Candidature.objects.filter(offre__entreprise__utilisateur=request.user).select_related(
        "etudiant", "etudiant__utilisateur", "offre"
    )
    offre_id = request.GET.get("offre", "")
    if offre_id.isdigit():
        candidatures = candidatures.filter(offre_id=offre_id)

    reponse = HttpResponse(content_type="text/csv; charset=utf-8")
    reponse["Content-Disposition"] = 'attachment; filename="candidatures.csv"'
    reponse.write("\ufeff")  # pour qu'Excel reconnaisse les accents
    ecrivain = csv.writer(reponse, delimiter=";")
    ecrivain.writerow(["Offre", "Candidat", "E-mail", "Formation", "Niveau", "Date de dépôt", "Statut"])
    for c in candidatures:
        ecrivain.writerow([
            c.offre.titre,
            c.etudiant.utilisateur.nom_complet,
            c.etudiant.utilisateur.email,
            c.etudiant.formation,
            c.etudiant.get_niveau_display(),
            c.date_depot.strftime("%d/%m/%Y"),
            c.get_statut_display(),
        ])
    return reponse
