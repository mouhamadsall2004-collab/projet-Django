from datetime import timedelta

from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from candidatures.models import Candidature
from comptes.models import Entreprise, Etudiant, Utilisateur
from offres.models import Offre


class CandidaturesTests(TestCase):
    def setUp(self):
        u_ent = Utilisateur.objects.create_user("ent1", password="Motdepasse123", role="entreprise")
        u_etu = Utilisateur.objects.create_user("etu1", password="Motdepasse123", role="etudiant")
        self.etudiant = Etudiant.objects.create(utilisateur=u_etu)
        entreprise = Entreprise.objects.create(utilisateur=u_ent, nom="Alpha")
        self.offre = Offre.objects.create(
            entreprise=entreprise,
            titre="Stage",
            description="Texte",
            localisation="Dakar",
            date_limite=timezone.localdate() + timedelta(days=5),
        )

    def test_un_etudiant_postule_une_seule_fois(self):
        self.client.login(username="etu1", password="Motdepasse123")
        url = reverse("candidatures:postuler", args=[self.offre.pk])
        donnees = {"lettre_motivation": "Je suis très motivé par ce stage dans votre entreprise."}
        self.client.post(url, donnees)
        self.client.post(url, donnees)
        self.assertEqual(Candidature.objects.count(), 1)

    def test_lettre_trop_courte_refusee(self):
        self.client.login(username="etu1", password="Motdepasse123")
        self.client.post(reverse("candidatures:postuler", args=[self.offre.pk]), {"lettre_motivation": "court"})
        self.assertEqual(Candidature.objects.count(), 0)

    def test_entreprise_change_le_statut(self):
        c = Candidature.objects.create(etudiant=self.etudiant, offre=self.offre, lettre_motivation="x" * 40)
        self.client.login(username="ent1", password="Motdepasse123")
        self.client.post(reverse("candidatures:changer_statut", args=[c.pk]), {"statut": "acceptee"})
        c.refresh_from_db()
        self.assertEqual(c.statut, "acceptee")

    def test_etudiant_ne_change_pas_le_statut(self):
        c = Candidature.objects.create(etudiant=self.etudiant, offre=self.offre, lettre_motivation="x" * 40)
        self.client.login(username="etu1", password="Motdepasse123")
        reponse = self.client.post(reverse("candidatures:changer_statut", args=[c.pk]), {"statut": "acceptee"})
        self.assertEqual(reponse.status_code, 403)

    def test_export_csv_reserve_a_l_entreprise(self):
        Candidature.objects.create(etudiant=self.etudiant, offre=self.offre, lettre_motivation="x" * 40)
        self.client.login(username="ent1", password="Motdepasse123")
        reponse = self.client.get(reverse("candidatures:exporter"))
        self.assertEqual(reponse.status_code, 200)
        self.assertIn("text/csv", reponse["Content-Type"])
        self.client.logout()
        self.client.login(username="etu1", password="Motdepasse123")
        self.assertEqual(self.client.get(reverse("candidatures:exporter")).status_code, 403)
