from django.urls import path

from . import views

app_name = "candidatures"

urlpatterns = [
    path("", views.mes_candidatures, name="mes_candidatures"),
    path("recues/", views.candidatures_recues, name="recues"),
    path("export/", views.exporter_csv, name="exporter"),
    path("postuler/<int:offre_pk>/", views.postuler, name="postuler"),
    path("<int:pk>/", views.candidature_detail, name="detail"),
    path("<int:pk>/statut/", views.changer_statut, name="changer_statut"),
    path("<int:pk>/retirer/", views.retirer, name="retirer"),
]
