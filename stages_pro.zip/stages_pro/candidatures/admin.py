from django.contrib import admin

from .models import Candidature


@admin.register(Candidature)
class CandidatureAdmin(admin.ModelAdmin):
    list_display = ("etudiant", "offre", "statut", "date_creation")
    list_filter = ("statut",)
    search_fields = ("etudiant__utilisateur__username", "offre__titre")
