from django.core.validators import FileExtensionValidator
from django.db import models

from comptes.models import Etudiant, HorodatageModel
from comptes.validateurs import valider_taille
from offres.models import Offre


class Candidature(HorodatageModel):
    class Statut(models.TextChoices):
        SOUMISE = "soumise", "Soumise"
        EN_COURS = "en_cours", "En cours d'étude"
        ACCEPTEE = "acceptee", "Acceptée"
        REFUSEE = "refusee", "Refusée"

    # statuts que l'entreprise peut attribuer (on ne revient pas à « soumise »)
    STATUTS_ATTRIBUABLES = (Statut.EN_COURS, Statut.ACCEPTEE, Statut.REFUSEE)

    etudiant = models.ForeignKey(Etudiant, on_delete=models.CASCADE, related_name="candidatures")
    offre = models.ForeignKey(Offre, on_delete=models.CASCADE, related_name="candidatures")
    lettre_motivation = models.TextField("lettre de motivation")
    cv = models.FileField(
        "CV (PDF)",
        upload_to="candidatures/",
        blank=True,
        validators=[FileExtensionValidator(["pdf"]), valider_taille],
    )
    statut = models.CharField("statut", max_length=10, choices=Statut.choices, default=Statut.SOUMISE)

    class Meta:
        ordering = ["-date_creation"]
        verbose_name = "candidature"
        verbose_name_plural = "candidatures"
        constraints = [
            # un étudiant ne peut postuler qu'une seule fois à la même offre
            models.UniqueConstraint(fields=["etudiant", "offre"], name="une_candidature_par_offre"),
        ]

    @property
    def date_depot(self):
        return self.date_creation

    @property
    def peut_etre_retiree(self):
        # l'étudiant peut retirer sa candidature tant qu'elle n'est pas traitée
        return self.statut == self.Statut.SOUMISE

    def changer_statut(self, nouveau_statut):
        if nouveau_statut not in [s.value for s in self.STATUTS_ATTRIBUABLES]:
            raise ValueError("Statut non autorisé.")
        self.statut = nouveau_statut
        self.save(update_fields=["statut", "date_modification"])

    def __str__(self):
        return f"{self.etudiant} pour {self.offre.titre}"
