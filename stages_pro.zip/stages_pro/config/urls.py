from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

from tableau_bord.views import accueil

urlpatterns = [
    path("", accueil, name="accueil"),
    path("compte/", include("comptes.urls")),
    path("offres/", include("offres.urls")),
    path("candidatures/", include("candidatures.urls")),
    path("espace/", include("tableau_bord.urls")),
    path("django-admin/", admin.site.urls),
]

# En développement, Django sert lui-même les fichiers envoyés (CV)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
