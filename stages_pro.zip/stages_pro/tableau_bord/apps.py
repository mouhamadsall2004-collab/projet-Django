from django.apps import AppConfig


class TableauBordConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tableau_bord"
    verbose_name = "Espace personnel et administration"
