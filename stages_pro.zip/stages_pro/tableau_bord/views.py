import os

from django.conf import settings
from django.contrib import messages
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.decorators.http import require_POST
from django.views.generic import DeleteView, ListView

from candidatures.models import Candidature
from comptes.mixins import QuerystringMixin, RoleRequiredMixin, SuppressionMixin, role_required
from comptes.models import SECTEURS, Utilisateur
from offres.models import Offre
from parametres.models import ParametresSite

from . import services
from .forms import ParametresForm

ADMIN = Utilisateur.Role.ADMIN


class AdminMixin(RoleRequiredMixin):
    roles_autorises = (ADMIN,)


def accueil(request):
    contexte = {
        "stats": services.statistiques_accueil(),
        "offres_recentes": Offre.objects.ouvertes().select_related("entreprise")[:6],
        "secteurs": SECTEURS,
    }
    return render(request, "accueil.html", contexte)


@role_required(*Utilisateur.Role.values)
def index(request):
    """Chaque rôle arrive sur son propre tableau de bord."""
    utilisateur = request.user

    if utilisateur.est_etudiant:
        etudiant = utilisateur.obtenir_profil()
        contexte = {
            "stats": services.statistiques_etudiant(etudiant),
            "dernieres_candidatures": Candidature.objects.filter(etudiant=etudiant).select_related(
                "offre", "offre__entreprise"
            )[:5],
            "offres_recentes": Offre.objects.ouvertes().select_related("entreprise")[:3],
        }
        return render(request, "tableau_bord/etudiant.html", contexte)

    if utilisateur.est_entreprise:
        entreprise = utilisateur.obtenir_profil()
        contexte = {
            "stats": services.statistiques_entreprise(entreprise),
            "dernieres_candidatures": Candidature.objects.filter(offre__entreprise=entreprise).select_related(
                "etudiant", "etudiant__utilisateur", "offre"
            )[:6],
        }
        return render(request, "tableau_bord/entreprise.html", contexte)

    return render(request, "tableau_bord/administrateur.html", {"stats": services.statistiques_admin()})


# ---------------------------------------------------------------------------
# Administration : comptes
# ---------------------------------------------------------------------------
class UtilisateursView(AdminMixin, QuerystringMixin, ListView):
    template_name = "tableau_bord/utilisateurs.html"
    context_object_name = "utilisateurs"
    paginate_by = 20

    def get_queryset(self):
        utilisateurs = Utilisateur.objects.order_by("-date_joined")
        recherche = self.request.GET.get("q", "").strip()
        role = self.request.GET.get("role", "")
        if recherche:
            utilisateurs = utilisateurs.filter(
                Q(username__icontains=recherche)
                | Q(first_name__icontains=recherche)
                | Q(last_name__icontains=recherche)
                | Q(email__icontains=recherche)
            )
        if role in Utilisateur.Role.values:
            utilisateurs = utilisateurs.filter(role=role)
        return utilisateurs

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["roles"] = Utilisateur.Role.choices
        contexte["recherche"] = self.request.GET.get("q", "")
        contexte["role_actif"] = self.request.GET.get("role", "")
        return contexte


@role_required(ADMIN)
@require_POST
def utilisateur_statut(request, pk):
    """Active ou désactive un compte."""
    cible = get_object_or_404(Utilisateur, pk=pk)
    if cible.pk == request.user.pk or cible.is_superuser:
        messages.error(request, "Ce compte ne peut pas être désactivé.")
    else:
        cible.is_active = not cible.is_active
        cible.save(update_fields=["is_active"])
        etat = "activé" if cible.is_active else "désactivé"
        messages.success(request, f"Le compte {cible.username} a été {etat}.")
    return redirect("tableau_bord:utilisateurs")


class UtilisateurSuppressionView(AdminMixin, SuppressionMixin, DeleteView):
    success_url = reverse_lazy("tableau_bord:utilisateurs")
    message_succes = "Le compte « {objet} » a été supprimé."
    message_avertissement = (
        "Son profil, ses offres et ses candidatures seront aussi supprimés. Cette action est définitive."
    )

    def get_queryset(self):
        # on ne peut supprimer ni son propre compte ni un super-utilisateur
        return Utilisateur.objects.exclude(pk=self.request.user.pk).exclude(is_superuser=True)


# ---------------------------------------------------------------------------
# Administration : offres
# ---------------------------------------------------------------------------
class OffresAdminView(AdminMixin, QuerystringMixin, ListView):
    template_name = "tableau_bord/offres.html"
    context_object_name = "offres"
    paginate_by = 20

    def get_queryset(self):
        offres = Offre.objects.select_related("entreprise").order_by("-date_creation")
        recherche = self.request.GET.get("q", "").strip()
        statut = self.request.GET.get("statut", "")
        if recherche:
            offres = offres.filter(Q(titre__icontains=recherche) | Q(entreprise__nom__icontains=recherche))
        if statut in Offre.Statut.values:
            offres = offres.filter(statut=statut)
        return offres

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["statuts"] = Offre.Statut.choices
        contexte["recherche"] = self.request.GET.get("q", "")
        contexte["statut_actif"] = self.request.GET.get("statut", "")
        return contexte


@role_required(ADMIN)
@require_POST
def offre_moderer(request, pk):
    """Masque une offre, ou la republie si elle était masquée."""
    offre = get_object_or_404(Offre, pk=pk)
    if offre.statut == Offre.Statut.MASQUEE:
        offre.statut = Offre.Statut.PUBLIEE
        messages.success(request, f"L'offre « {offre.titre} » est de nouveau publiée.")
    else:
        offre.statut = Offre.Statut.MASQUEE
        messages.success(request, f"L'offre « {offre.titre} » a été masquée.")
    offre.save(update_fields=["statut", "date_modification"])
    return redirect("tableau_bord:offres")


class OffreSuppressionAdminView(AdminMixin, SuppressionMixin, DeleteView):
    model = Offre
    success_url = reverse_lazy("tableau_bord:offres")
    message_succes = "L'offre « {objet} » a été supprimée."
    message_avertissement = "Les candidatures liées à cette offre seront aussi supprimées."


# ---------------------------------------------------------------------------
# Administration : candidatures
# ---------------------------------------------------------------------------
class CandidaturesAdminView(AdminMixin, QuerystringMixin, ListView):
    template_name = "tableau_bord/candidatures.html"
    context_object_name = "candidatures"
    paginate_by = 20

    def get_queryset(self):
        candidatures = Candidature.objects.select_related(
            "etudiant", "etudiant__utilisateur", "offre", "offre__entreprise"
        ).order_by("-date_creation")
        recherche = self.request.GET.get("q", "").strip()
        statut = self.request.GET.get("statut", "")
        if recherche:
            candidatures = candidatures.filter(
                Q(offre__titre__icontains=recherche)
                | Q(etudiant__utilisateur__username__icontains=recherche)
                | Q(etudiant__utilisateur__last_name__icontains=recherche)
            )
        if statut in Candidature.Statut.values:
            candidatures = candidatures.filter(statut=statut)
        return candidatures

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["statuts"] = Candidature.Statut.choices
        contexte["recherche"] = self.request.GET.get("q", "")
        contexte["statut_actif"] = self.request.GET.get("statut", "")
        return contexte


class CandidatureSuppressionView(AdminMixin, SuppressionMixin, DeleteView):
    model = Candidature
    success_url = reverse_lazy("tableau_bord:candidatures")
    message_succes = "La candidature « {objet} » a été supprimée."


# ---------------------------------------------------------------------------
# Administration : paramètres du site (textes de l'accueil et coordonnées)
# ---------------------------------------------------------------------------
@role_required(ADMIN)
def parametres(request):
    parametres_site = ParametresSite.charger()
    form = ParametresForm(request.POST or None, instance=parametres_site)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Les paramètres du site ont été enregistrés.")
        return redirect("tableau_bord:parametres")
    return render(request, "tableau_bord/parametres.html", {"form": form})


# ---------------------------------------------------------------------------
# Administration : suppression des données
# ---------------------------------------------------------------------------
CIBLES_SUPPRESSION = {
    "candidatures": {
        "titre": "Toutes les candidatures",
        "texte": "Supprime toutes les candidatures. Les comptes et les offres sont conservés.",
        "donnees": lambda: Candidature.objects.all(),
    },
    "offres": {
        "titre": "Toutes les offres",
        "texte": "Supprime toutes les offres et, avec elles, leurs candidatures.",
        "donnees": lambda: Offre.objects.all(),
    },
    "comptes": {
        "titre": "Tous les comptes étudiants et entreprises",
        "texte": (
            "Supprime tous les comptes étudiants et entreprises, avec leurs profils, leurs offres "
            "et leurs candidatures. Les comptes administrateurs sont conservés."
        ),
        "donnees": lambda: Utilisateur.objects.exclude(role=ADMIN).exclude(is_superuser=True),
    },
}
MOT_DE_CONFIRMATION = "SUPPRIMER"


@role_required(ADMIN)
def base_de_donnees(request):
    if request.method == "POST":
        cible = request.POST.get("cible", "")
        if cible not in CIBLES_SUPPRESSION:
            messages.error(request, "Choix de suppression inconnu.")
        elif request.POST.get("confirmation", "").strip() != MOT_DE_CONFIRMATION:
            messages.error(request, f"Pour confirmer, tapez exactement : {MOT_DE_CONFIRMATION}")
        else:
            with transaction.atomic():
                total, _ = CIBLES_SUPPRESSION[cible]["donnees"]().delete()
            messages.success(request, f"{total} enregistrement(s) supprimé(s).")
        return redirect("tableau_bord:base_de_donnees")

    cibles = [
        {"cle": cle, "titre": c["titre"], "texte": c["texte"], "nombre": c["donnees"]().count()}
        for cle, c in CIBLES_SUPPRESSION.items()
    ]

    fichier = settings.DATABASES["default"]["NAME"]
    taille_ko = round(os.path.getsize(fichier) / 1024) if os.path.exists(fichier) else 0
    contexte = {
        "cibles": cibles,
        "nom_fichier": os.path.basename(str(fichier)),
        "taille_ko": taille_ko,
        "mot_de_confirmation": MOT_DE_CONFIRMATION,
    }
    return render(request, "tableau_bord/base_de_donnees.html", contexte)
