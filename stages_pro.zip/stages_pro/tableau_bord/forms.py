from django import forms

from comptes.mixins import StyledFormMixin
from parametres.models import ParametresSite


class ParametresForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = ParametresSite
        fields = [
            "nom_site",
            "titre_accueil",
            "sous_titre_accueil",
            "email_contact",
            "telephone_contact",
            "adresse",
        ]
        widgets = {
            "sous_titre_accueil": forms.Textarea(attrs={"rows": 3}),
        }
