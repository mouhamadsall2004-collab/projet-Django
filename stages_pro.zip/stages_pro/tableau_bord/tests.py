import tempfile
from datetime import timedelta

from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from candidatures.models import Candidature
from comptes.models import Entreprise, Etudiant, Utilisateur
from offres.models import Offre
from parametres.models import ParametresSite


def creer_donnees():
    admin = Utilisateur.objects.create_user("admin1", password="Motdepasse123", role=Utilisateur.Role.ADMIN)
    u_etu = Utilisateur.objects.create_user("etu1", password="Motdepasse123", role=Utilisateur.Role.ETUDIANT)
    u_ent = Utilisateur.objects.create_user("ent1", password="Motdepasse123", role=Utilisateur.Role.ENTREPRISE)
    etudiant = Etudiant.objects.create(utilisateur=u_etu)
    entreprise = Entreprise.objects.create(utilisateur=u_ent, nom="Société de test")
    offre = Offre.objects.create(
        entreprise=entreprise,
        titre="Stage développeur",
        description="Description",
        localisation="Dakar",
        date_limite=timezone.localdate() + timedelta(days=10),
    )
    candidature = Candidature.objects.create(etudiant=etudiant, offre=offre, lettre_motivation="x" * 40)
    return admin, u_etu, u_ent, offre, candidature


@override_settings(MEDIA_ROOT=tempfile.mkdtemp())
class AdministrationTests(TestCase):
    def setUp(self):
        self.admin, self.u_etu, self.u_ent, self.offre, self.candidature = creer_donnees()

    def test_accueil_sans_donnees(self):
        Candidature.objects.all().delete()
        reponse = self.client.get(reverse("accueil"))
        self.assertEqual(reponse.status_code, 200)
        self.assertContains(reponse, "Rechercher")

    def test_pages_admin_interdites_aux_autres_roles(self):
        self.client.login(username="etu1", password="Motdepasse123")
        for nom in ("utilisateurs", "offres", "candidatures", "parametres", "base_de_donnees"):
            self.assertEqual(self.client.get(reverse(f"tableau_bord:{nom}")).status_code, 403, nom)

    def test_visiteur_redirige_vers_connexion(self):
        reponse = self.client.get(reverse("tableau_bord:utilisateurs"))
        self.assertEqual(reponse.status_code, 302)

    def test_admin_change_les_textes_de_l_accueil(self):
        self.client.login(username="admin1", password="Motdepasse123")
        reponse = self.client.post(
            reverse("tableau_bord:parametres"),
            {"nom_site": "Mon site", "titre_accueil": "Nouveau titre", "sous_titre_accueil": "Sous-titre"},
        )
        self.assertEqual(reponse.status_code, 302)
        self.assertContains(self.client.get(reverse("accueil")), "Nouveau titre")

    def test_admin_supprime_un_utilisateur(self):
        self.client.login(username="admin1", password="Motdepasse123")
        url = reverse("tableau_bord:utilisateur_supprimer", args=[self.u_ent.pk])
        self.assertEqual(self.client.get(url).status_code, 200)
        self.client.post(url)
        self.assertFalse(Utilisateur.objects.filter(pk=self.u_ent.pk).exists())
        # l'offre et la candidature partent avec le compte
        self.assertEqual(Offre.objects.count(), 0)
        self.assertEqual(Candidature.objects.count(), 0)

    def test_admin_ne_peut_pas_se_supprimer(self):
        self.client.login(username="admin1", password="Motdepasse123")
        reponse = self.client.post(reverse("tableau_bord:utilisateur_supprimer", args=[self.admin.pk]))
        self.assertEqual(reponse.status_code, 404)
        self.assertTrue(Utilisateur.objects.filter(pk=self.admin.pk).exists())

    def test_admin_supprime_offre_et_candidature(self):
        self.client.login(username="admin1", password="Motdepasse123")
        self.client.post(reverse("tableau_bord:candidature_supprimer", args=[self.candidature.pk]))
        self.assertEqual(Candidature.objects.count(), 0)
        self.client.post(reverse("tableau_bord:offre_supprimer", args=[self.offre.pk]))
        self.assertEqual(Offre.objects.count(), 0)

    def test_purge_exige_la_confirmation(self):
        self.client.login(username="admin1", password="Motdepasse123")
        url = reverse("tableau_bord:base_de_donnees")
        self.client.post(url, {"cible": "candidatures", "confirmation": "oui"})
        self.assertEqual(Candidature.objects.count(), 1)
        self.client.post(url, {"cible": "candidatures", "confirmation": "SUPPRIMER"})
        self.assertEqual(Candidature.objects.count(), 0)
        self.assertEqual(Offre.objects.count(), 1)

    def test_purge_des_comptes_garde_les_administrateurs(self):
        self.client.login(username="admin1", password="Motdepasse123")
        self.client.post(reverse("tableau_bord:base_de_donnees"), {"cible": "comptes", "confirmation": "SUPPRIMER"})
        self.assertEqual(Utilisateur.objects.count(), 1)
        self.assertTrue(Utilisateur.objects.filter(username="admin1").exists())

    def test_masquer_une_offre(self):
        self.client.login(username="admin1", password="Motdepasse123")
        self.client.post(reverse("tableau_bord:offre_moderer", args=[self.offre.pk]))
        self.offre.refresh_from_db()
        self.assertEqual(self.offre.statut, Offre.Statut.MASQUEE)
