from django.urls import path

from . import views

app_name = "tableau_bord"

urlpatterns = [
    path("", views.index, name="index"),

    # administration
    path("utilisateurs/", views.UtilisateursView.as_view(), name="utilisateurs"),
    path("utilisateurs/<int:pk>/statut/", views.utilisateur_statut, name="utilisateur_statut"),
    path("utilisateurs/<int:pk>/supprimer/", views.UtilisateurSuppressionView.as_view(), name="utilisateur_supprimer"),

    path("offres/", views.OffresAdminView.as_view(), name="offres"),
    path("offres/<int:pk>/moderer/", views.offre_moderer, name="offre_moderer"),
    path("offres/<int:pk>/supprimer/", views.OffreSuppressionAdminView.as_view(), name="offre_supprimer"),

    path("candidatures/", views.CandidaturesAdminView.as_view(), name="candidatures"),
    path("candidatures/<int:pk>/supprimer/", views.CandidatureSuppressionView.as_view(), name="candidature_supprimer"),

    path("parametres/", views.parametres, name="parametres"),
    path("base-de-donnees/", views.base_de_donnees, name="base_de_donnees"),
]
