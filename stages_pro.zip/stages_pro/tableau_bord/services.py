# Calculs des statistiques affichées sur l'accueil et dans les tableaux de bord
from django.db.models import Count

from candidatures.models import Candidature
from comptes.models import SECTEURS, Entreprise, Etudiant, Utilisateur
from offres.models import Offre


def repartition(queryset, champ, choix, couleur_statut=False):
    """Compte les objets par valeur du champ, pour dessiner des barres."""
    comptes = dict(queryset.order_by().values_list(champ).annotate(n=Count("pk")))
    maximum = max(comptes.values(), default=0) or 1

    lignes = []
    for position, (cle, libelle) in enumerate(choix):
        valeur = comptes.get(cle, 0)
        lignes.append({
            "cle": cle,
            "libelle": libelle,
            "valeur": valeur,
            "pourcent": round(valeur * 100 / maximum),
            "classe": f"barre-{cle}" if couleur_statut else "barre-neutre",
        })
    return lignes


def statistiques_accueil():
    return {
        "offres_ouvertes": Offre.objects.ouvertes().count(),
        "stages": Offre.objects.ouvertes().filter(type_offre=Offre.Type.STAGE).count(),
        "emplois": Offre.objects.ouvertes().filter(type_offre=Offre.Type.EMPLOI).count(),
        "entreprises": Entreprise.objects.count(),
        "etudiants": Etudiant.objects.count(),
        "candidatures": Candidature.objects.count(),
    }


def statistiques_etudiant(etudiant):
    candidatures = Candidature.objects.filter(etudiant=etudiant)
    return {
        "total": candidatures.count(),
        "en_cours": candidatures.filter(statut=Candidature.Statut.EN_COURS).count(),
        "acceptees": candidatures.filter(statut=Candidature.Statut.ACCEPTEE).count(),
        "par_statut": repartition(candidatures, "statut", Candidature.Statut.choices, True),
    }


def statistiques_entreprise(entreprise):
    offres = Offre.objects.filter(entreprise=entreprise)
    candidatures = Candidature.objects.filter(offre__entreprise=entreprise)
    return {
        "offres": offres.count(),
        "offres_ouvertes": offres.ouvertes().count(),
        "candidatures": candidatures.count(),
        "a_traiter": candidatures.filter(statut=Candidature.Statut.SOUMISE).count(),
        "par_statut": repartition(candidatures, "statut", Candidature.Statut.choices, True),
    }


def statistiques_admin():
    candidatures = Candidature.objects.all()
    offres = Offre.objects.all()
    total = candidatures.count()
    acceptees = candidatures.filter(statut=Candidature.Statut.ACCEPTEE).count()
    return {
        "utilisateurs": Utilisateur.objects.count(),
        "offres": offres.count(),
        "candidatures": total,
        "taux_acceptation": round(acceptees * 100 / total) if total else 0,
        "par_role": repartition(Utilisateur.objects.all(), "role", Utilisateur.Role.choices),
        "offres_par_type": repartition(offres, "type_offre", Offre.Type.choices),
        "offres_par_statut": repartition(offres, "statut", Offre.Statut.choices, True),
        "offres_par_secteur": repartition(offres, "secteur", SECTEURS),
        "candidatures_par_statut": repartition(candidatures, "statut", Candidature.Statut.choices, True),
    }
