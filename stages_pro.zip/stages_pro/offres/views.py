from django.contrib import messages
from django.db.models import Count, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.views.decorators.http import require_POST
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from comptes.mixins import QuerystringMixin, RoleRequiredMixin, SuppressionMixin, role_required
from comptes.models import Utilisateur

from .forms import OffreForm, RechercheOffreForm
from .models import Favori, Offre

ENTREPRISE = Utilisateur.Role.ENTREPRISE
ETUDIANT = Utilisateur.Role.ETUDIANT


class OffreListView(QuerystringMixin, ListView):
    """Catalogue public : offres ouvertes, avec recherche et pagination."""

    template_name = "offres/liste.html"
    context_object_name = "offres"
    paginate_by = 9

    def get_queryset(self):
        offres = Offre.objects.ouvertes().select_related("entreprise")
        self.form = RechercheOffreForm(self.request.GET or None)
        return self.form.filtrer(offres)

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        contexte["form"] = self.form
        return contexte


class OffreDetailView(DetailView):
    template_name = "offres/detail.html"
    context_object_name = "offre"

    def get_queryset(self):
        return Offre.objects.select_related("entreprise", "entreprise__utilisateur")

    def get_object(self, queryset=None):
        offre = super().get_object(queryset)
        utilisateur = self.request.user
        connecte = utilisateur.is_authenticated
        self.est_proprietaire = connecte and offre.entreprise.utilisateur_id == utilisateur.pk
        est_admin = connecte and utilisateur.est_admin
        # une offre masquée par la modération n'est visible que par son auteur et l'administrateur
        if offre.statut == Offre.Statut.MASQUEE and not (self.est_proprietaire or est_admin):
            raise Http404("Offre introuvable.")
        return offre

    def get_context_data(self, **kwargs):
        contexte = super().get_context_data(**kwargs)
        utilisateur = self.request.user
        offre = self.object
        deja_postule = (
            utilisateur.is_authenticated
            and utilisateur.est_etudiant
            and offre.candidatures.filter(etudiant__utilisateur=utilisateur).exists()
        )
        contexte["est_favori"] = (
            utilisateur.is_authenticated
            and utilisateur.est_etudiant
            and Favori.objects.filter(etudiant__utilisateur=utilisateur, offre=offre).exists()
        )
        contexte["est_proprietaire"] = self.est_proprietaire
        contexte["deja_postule"] = deja_postule
        contexte["nb_candidatures"] = offre.candidatures.count() if self.est_proprietaire else None
        return contexte


class OffreCreateView(RoleRequiredMixin, CreateView):
    roles_autorises = (ENTREPRISE,)
    form_class = OffreForm
    template_name = "offres/formulaire.html"
    extra_context = {"titre_page": "Publier une offre"}

    def form_valid(self, form):
        form.instance.entreprise = self.request.user.obtenir_profil()
        messages.success(self.request, "Votre offre a été publiée.")
        return super().form_valid(form)

    def get_success_url(self):
        return reverse("offres:detail", args=[self.object.pk])


class OffreUpdateView(RoleRequiredMixin, UpdateView):
    roles_autorises = (ENTREPRISE,)
    form_class = OffreForm
    template_name = "offres/formulaire.html"
    extra_context = {"titre_page": "Modifier l'offre"}

    def get_queryset(self):
        # une entreprise ne modifie que ses propres offres
        return Offre.objects.filter(entreprise__utilisateur=self.request.user)

    def form_valid(self, form):
        messages.success(self.request, "L'offre a été modifiée.")
        return super().form_valid(form)

    def get_success_url(self):
        return reverse("offres:detail", args=[self.object.pk])


class OffreSuppressionView(RoleRequiredMixin, SuppressionMixin, DeleteView):
    roles_autorises = (ENTREPRISE,)
    success_url = reverse_lazy("offres:mes_offres")
    message_succes = "L'offre « {objet} » a été supprimée."
    message_avertissement = "Les candidatures reçues pour cette offre seront aussi supprimées."

    def get_queryset(self):
        return Offre.objects.filter(entreprise__utilisateur=self.request.user)


class MesOffresView(RoleRequiredMixin, ListView):
    roles_autorises = (ENTREPRISE,)
    template_name = "offres/mes_offres.html"
    context_object_name = "offres"

    def get_queryset(self):
        return (
            Offre.objects.filter(entreprise__utilisateur=self.request.user)
            .annotate(
                nb_candidatures=Count("candidatures"),
                nb_nouvelles=Count("candidatures", filter=Q(candidatures__statut="soumise")),
            )
            .order_by("-date_creation")
        )


@role_required(ENTREPRISE)
@require_POST
def cloturer(request, pk):
    offre = get_object_or_404(Offre, pk=pk, entreprise__utilisateur=request.user)
    if offre.cloturer():
        messages.success(request, f"L'offre « {offre.titre} » a été clôturée.")
    else:
        messages.warning(request, "Cette offre ne peut pas être clôturée.")
    return redirect("offres:mes_offres")


@role_required(ETUDIANT)
@require_POST
def basculer_favori(request, pk):
    """Enregistre l'offre, ou la retire si elle était déjà enregistrée."""
    offre = get_object_or_404(Offre.objects.publiees(), pk=pk)
    favori, cree = Favori.objects.get_or_create(etudiant=request.user.obtenir_profil(), offre=offre)
    if cree:
        messages.success(request, "L'offre a été ajoutée à vos offres enregistrées.")
    else:
        favori.delete()
        messages.success(request, "L'offre a été retirée de vos offres enregistrées.")
    return redirect("offres:detail", pk=offre.pk)


class MesFavorisView(RoleRequiredMixin, ListView):
    roles_autorises = (ETUDIANT,)
    template_name = "offres/favoris.html"
    context_object_name = "favoris"

    def get_queryset(self):
        return Favori.objects.filter(etudiant__utilisateur=self.request.user).select_related(
            "offre", "offre__entreprise"
        )
