from datetime import timedelta

from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from comptes.models import Entreprise, Etudiant, Utilisateur
from offres.models import Offre


class OffresTests(TestCase):
    def setUp(self):
        u_ent = Utilisateur.objects.create_user("ent1", password="Motdepasse123", role="entreprise")
        u_ent2 = Utilisateur.objects.create_user("ent2", password="Motdepasse123", role="entreprise")
        u_etu = Utilisateur.objects.create_user("etu1", password="Motdepasse123", role="etudiant")
        self.entreprise = Entreprise.objects.create(utilisateur=u_ent, nom="Alpha")
        Entreprise.objects.create(utilisateur=u_ent2, nom="Beta")
        Etudiant.objects.create(utilisateur=u_etu)
        self.offre = Offre.objects.create(
            entreprise=self.entreprise,
            titre="Stage réseau",
            description="Texte",
            localisation="Thiès",
            date_limite=timezone.localdate() + timedelta(days=5),
        )

    def test_liste_publique_et_recherche(self):
        self.assertContains(self.client.get(reverse("offres:liste")), "Stage réseau")
        self.assertNotContains(self.client.get(reverse("offres:liste"), {"q": "introuvable"}), "Stage réseau")

    def test_offre_expiree_absente_du_catalogue(self):
        self.offre.date_limite = timezone.localdate() - timedelta(days=1)
        self.offre.save()
        self.assertNotContains(self.client.get(reverse("offres:liste")), "Stage réseau")

    def test_etudiant_ne_peut_pas_publier(self):
        self.client.login(username="etu1", password="Motdepasse123")
        self.assertEqual(self.client.get(reverse("offres:creer")).status_code, 403)

    def test_entreprise_ne_modifie_pas_l_offre_d_une_autre(self):
        self.client.login(username="ent2", password="Motdepasse123")
        self.assertEqual(self.client.get(reverse("offres:modifier", args=[self.offre.pk])).status_code, 404)

    def test_offre_masquee_invisible_au_public(self):
        self.offre.statut = Offre.Statut.MASQUEE
        self.offre.save()
        self.assertEqual(self.client.get(reverse("offres:detail", args=[self.offre.pk])).status_code, 404)


class FavorisTests(TestCase):
    def setUp(self):
        u_ent = Utilisateur.objects.create_user("ent1", password="Motdepasse123", role="entreprise")
        u_etu = Utilisateur.objects.create_user("etu1", password="Motdepasse123", role="etudiant")
        Etudiant.objects.create(utilisateur=u_etu)
        entreprise = Entreprise.objects.create(utilisateur=u_ent, nom="Alpha")
        self.offre = Offre.objects.create(
            entreprise=entreprise,
            titre="Stage",
            description="Texte",
            localisation="Dakar",
            date_limite=timezone.localdate() + timedelta(days=5),
        )

    def test_enregistrer_puis_retirer(self):
        from offres.models import Favori

        self.client.login(username="etu1", password="Motdepasse123")
        url = reverse("offres:favori", args=[self.offre.pk])
        self.client.post(url)
        self.assertEqual(Favori.objects.count(), 1)
        self.assertContains(self.client.get(reverse("offres:favoris")), "Stage")
        self.client.post(url)
        self.assertEqual(Favori.objects.count(), 0)

    def test_entreprise_ne_peut_pas_enregistrer(self):
        self.client.login(username="ent1", password="Motdepasse123")
        self.assertEqual(self.client.post(reverse("offres:favori", args=[self.offre.pk])).status_code, 403)
