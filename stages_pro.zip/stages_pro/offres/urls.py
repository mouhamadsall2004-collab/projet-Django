from django.urls import path

from . import views

app_name = "offres"

urlpatterns = [
    path("", views.OffreListView.as_view(), name="liste"),
    path("nouvelle/", views.OffreCreateView.as_view(), name="creer"),
    path("mes-offres/", views.MesOffresView.as_view(), name="mes_offres"),
    path("enregistrees/", views.MesFavorisView.as_view(), name="favoris"),
    path("<int:pk>/", views.OffreDetailView.as_view(), name="detail"),
    path("<int:pk>/modifier/", views.OffreUpdateView.as_view(), name="modifier"),
    path("<int:pk>/supprimer/", views.OffreSuppressionView.as_view(), name="supprimer"),
    path("<int:pk>/enregistrer/", views.basculer_favori, name="favori"),
    path("<int:pk>/cloturer/", views.cloturer, name="cloturer"),
]
