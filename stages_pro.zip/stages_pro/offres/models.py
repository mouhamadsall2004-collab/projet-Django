from django.db import models
from django.utils import timezone

from comptes.models import SECTEURS, Entreprise, HorodatageModel


class OffreQuerySet(models.QuerySet):
    def publiees(self):
        return self.filter(statut=Offre.Statut.PUBLIEE)

    def ouvertes(self):
        # publiées et dont la date limite n'est pas encore passée
        return self.publiees().filter(date_limite__gte=timezone.localdate())


class Offre(HorodatageModel):
    class Type(models.TextChoices):
        STAGE = "stage", "Stage"
        EMPLOI = "emploi", "Emploi"

    class Statut(models.TextChoices):
        PUBLIEE = "publiee", "Publiée"
        CLOTUREE = "cloturee", "Clôturée"
        MASQUEE = "masquee", "Masquée"

    entreprise = models.ForeignKey(Entreprise, on_delete=models.CASCADE, related_name="offres")
    titre = models.CharField("titre", max_length=200)
    description = models.TextField("description du poste")
    profil_recherche = models.TextField("profil recherché", blank=True)
    type_offre = models.CharField("type", max_length=10, choices=Type.choices, default=Type.STAGE)
    secteur = models.CharField("secteur", max_length=20, choices=SECTEURS, default="informatique")
    localisation = models.CharField("lieu", max_length=150)
    duree = models.CharField("durée", max_length=60, blank=True, help_text="Par exemple : 3 mois, CDI.")
    date_debut = models.DateField("date de début", null=True, blank=True)
    date_limite = models.DateField("date limite de candidature")
    statut = models.CharField("statut", max_length=10, choices=Statut.choices, default=Statut.PUBLIEE)

    objects = OffreQuerySet.as_manager()

    class Meta:
        ordering = ["-date_creation"]
        verbose_name = "offre"
        verbose_name_plural = "offres"

    @property
    def est_ouverte(self):
        return self.statut == self.Statut.PUBLIEE and self.date_limite >= timezone.localdate()

    @property
    def jours_restants(self):
        return max((self.date_limite - timezone.localdate()).days, 0)

    def cloturer(self):
        """Clôture l'offre. Renvoie False si elle n'était pas publiée."""
        if self.statut != self.Statut.PUBLIEE:
            return False
        self.statut = self.Statut.CLOTUREE
        self.save(update_fields=["statut", "date_modification"])
        return True

    def __str__(self):
        return f"{self.titre} - {self.entreprise.nom}"


class Favori(HorodatageModel):
    """Offre enregistrée par un étudiant pour la retrouver plus tard."""

    etudiant = models.ForeignKey("comptes.Etudiant", on_delete=models.CASCADE, related_name="favoris")
    offre = models.ForeignKey(Offre, on_delete=models.CASCADE, related_name="favoris")

    class Meta:
        ordering = ["-date_creation"]
        verbose_name = "offre enregistrée"
        verbose_name_plural = "offres enregistrées"
        constraints = [
            models.UniqueConstraint(fields=["etudiant", "offre"], name="un_favori_par_offre"),
        ]

    def __str__(self):
        return f"{self.etudiant} - {self.offre.titre}"
