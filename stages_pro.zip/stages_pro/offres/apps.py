from django.apps import AppConfig


class OffresConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "offres"
    verbose_name = "Offres de stage et d'emploi"
