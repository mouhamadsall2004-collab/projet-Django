from django import forms
from django.db.models import Q
from django.utils import timezone

from comptes.mixins import StyledFormMixin
from comptes.models import SECTEURS

from .models import Offre


def champ_date():
    return forms.DateInput(format="%Y-%m-%d", attrs={"type": "date"})


class OffreForm(StyledFormMixin, forms.ModelForm):
    class Meta:
        model = Offre
        fields = [
            "titre",
            "type_offre",
            "secteur",
            "localisation",
            "duree",
            "date_debut",
            "date_limite",
            "description",
            "profil_recherche",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 8}),
            "profil_recherche": forms.Textarea(attrs={"rows": 5}),
            "date_debut": champ_date(),
            "date_limite": champ_date(),
        }

    def clean_date_limite(self):
        date_limite = self.cleaned_data["date_limite"]
        inchangee = self.instance.pk and date_limite == self.instance.date_limite
        if date_limite < timezone.localdate() and not inchangee:
            raise forms.ValidationError("La date limite ne peut pas être dans le passé.")
        return date_limite

    def clean(self):
        donnees = super().clean()
        debut = donnees.get("date_debut")
        limite = donnees.get("date_limite")
        if debut and limite and debut < limite:
            self.add_error("date_debut", "Le début doit être après la date limite de candidature.")
        return donnees


class RechercheOffreForm(StyledFormMixin, forms.Form):
    q = forms.CharField(
        label="Mot-clé",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Titre, entreprise, compétence"}),
    )
    type_offre = forms.ChoiceField(
        label="Type", required=False, choices=[("", "Tous les types")] + Offre.Type.choices
    )
    secteur = forms.ChoiceField(
        label="Secteur", required=False, choices=[("", "Tous les secteurs")] + SECTEURS
    )
    localisation = forms.CharField(
        label="Lieu",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Dakar, Thiès, Saint-Louis"}),
    )

    def filtrer(self, queryset):
        """Applique les critères saisis à une liste d'offres."""
        if not self.is_valid():
            return queryset
        d = self.cleaned_data
        if d["q"]:
            queryset = queryset.filter(
                Q(titre__icontains=d["q"])
                | Q(description__icontains=d["q"])
                | Q(profil_recherche__icontains=d["q"])
                | Q(entreprise__nom__icontains=d["q"])
            )
        if d["type_offre"]:
            queryset = queryset.filter(type_offre=d["type_offre"])
        if d["secteur"]:
            queryset = queryset.filter(secteur=d["secteur"])
        if d["localisation"]:
            queryset = queryset.filter(localisation__icontains=d["localisation"])
        return queryset
